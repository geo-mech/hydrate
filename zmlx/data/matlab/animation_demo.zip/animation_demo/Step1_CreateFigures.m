tri = load('Triangles.txt')+1; xy = load('Nodes.txt');x = xy(:,1);y = xy(:,2);

mkdir('Figures')
dirs = dir('Demo_Results');
for i = 3: 1: length(dirs)
    name = dirs(i).name;
    ipath = ['Demo_Results\', name];
    opath = ['Figures\', name];
    disp(ipath);
    d = load(ipath);
    % �����￪ʼ��ͼ
    trisurf(tri,x,y,d(:,1));
    shading interp;
    axis([-0.5,0.5,-0.5,0.5,-0.015,0.015])
    caxis([-0.015,0.015])
    view(-6.5,78); box on;
    % ��ͼ����������ͼƬ
    printfig('dir', opath, 'dpi', 150)
end
