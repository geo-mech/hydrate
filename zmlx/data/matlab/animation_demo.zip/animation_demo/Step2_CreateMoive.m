
myobj= VideoWriter('myvideo.avi');
myobj.FrameRate = 5;

open(myobj);
dirs = dir('Figures');
for i = 3: 1: length(dirs)
    name = dirs(i).name;
    ipath = ['Figures\', name];
    disp(ipath);
    frame = imread(ipath);
    writeVideo(myobj, frame);
end
close(myobj)
